# Anki flashcard generator

In this project, I'm using an LLM to automatically generate flashcards for spaced repetition software [Anki](https://apps.ankiweb.net/).

## Setup

1. Create a new virtual environment:

```sh
python -m venv .venv
```

Or use the `Create environment` action in VSCode.

2. Activate the environment:

In `bash` or `zsh`:

```sh
source .venv/bin/activate
```

In `fish`:

```sh
source .venv/bin/activate.fish
```

3. Install the dependencies:

```sh
pip install -r requirements.txt
```

4. Create a `.env` file and add your OpenAI API key:

```sh
OPENAI_API_KEY=<your-openai-api-key>
```
